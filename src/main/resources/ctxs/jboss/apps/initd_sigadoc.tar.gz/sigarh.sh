#!/bin/sh
#
# JBoss standalone control script
#
# chkconfig: - 80 20
# description: JBoss AS Standalone
# processname: standalone
# pidfile: /var/run/jboss-as/jboss-as-standalone.pid
# config: /etc/jboss-as/jboss-as.conf

# Source function library.
. /etc/init.d/functions

#verifica o usuário logado
CURRENT_USER=$(whoami)
if [ "$CURRENT_USER" != "jboss" ] && [ "$CURRENT_USER" != "root" ];then
  echo "Este script precisa ser utilizado com o usuario jboss ou root"
  exit 1
fi
SUBIT=""
if [ $CURRENT_USER == "root" ]; then
  SUBIT="su -l jboss -c "
fi

# Auto discover IP on eth0
#IP=$( ip addr s eth0 | grep -e "inet " | cut -d ' ' -f6 )
#IP=${IP%/*}
IP=0.0.0.0

########################################
#  Propriedades do JBoss               #
########################################
SERVER_NAME="sigarh"
SERVER_PORTS_OFFSET=100

JAVA_HOME=/opt/jdk1.6.0_45
JBOSS_HOME=/opt/jboss
SHUTDOWN_WAIT=30
JBOSS_SCRIPT=$JBOSS_HOME/bin/standalone.sh
JBOSS_LOG_DIR=/var/log/jboss/
JBOSS_CONSOLE_LOG=$JBOSS_LOG_DIR/$SERVER_NAME/console.log
JBOSS_PIDFILE=/var/run/jboss/$SERVER_NAME.pid

SERVER_BASE_DIR="$JBOSS_HOME/$SERVER_NAME"
SERVER_LOG_DIR=$JBOSS_LOG_DIR/$SERVER_NAME
SERVER_IP=$IP
#PROPERTIES_FILE="/opt/jboss/sigarh/properties/sigasgp.properties"

RUN_CONF="/opt/jboss/bin/init.d/sigarh.conf"

SIGARH_PROPS=" -Dorg.apache.el.parser.COERCE_TO_ZERO=false -Dorg.apache.catalina.STRICT_SERVLET_COMPLIANCE=false "

JBOSS_OPTS="-Djboss.server.base.dir=$SERVER_BASE_DIR -Djboss.server.log.dir=$SERVER_LOG_DIR -Djboss.bind.address=$SERVER_IP -Djboss.bind.address.management=$SERVER_IP -Djboss.socket.binding.port-offset=$SERVER_PORTS_OFFSET $SIGARH_PROPS"

# Exports
export JAVA_HOME
export JBOSS_HOME
export JBOSS_PIDFILE
export CUSTOM_JAVA_OPTS

function readLog(){
    tail -100f ${JBOSS_CONSOLE_LOG}
}

start() {
  if [ -f $JBOSS_PIDFILE ]; then
    read ppid < $JBOSS_PIDFILE
    if [ `ps --pid $ppid 2> /dev/null | grep -c $ppid 2> /dev/null` -eq '1' ]; then
      echo -n "$SERVER_NAME já está em execução"
      failure
      echo
      return 1 
    else
      rm -f $JBOSS_PIDFILE
    fi
  fi

  echo -n "Iniciando o $SERVER_NAME ..."

  cat /dev/null > $JBOSS_CONSOLE_LOG
  
  JBOSS_CMD_START="LAUNCH_JBOSS_IN_BACKGROUND=1 JBOSS_PIDFILE=$JBOSS_PIDFILE RUN_CONF=$RUN_CONF"
  $SUBIT "$JBOSS_CMD_START $JBOSS_SCRIPT $JBOSS_OPTS >${JBOSS_CONSOLE_LOG} 2>&1 &"

  echo ""
  echo "Gostaria de acompanhar os logs? (s/n)"
  read readLogs
  if [ "$readLogs" == "s" ]; then
     readLog
  fi

}

stop() {
  echo -n $"Parando o $SERVER_NAME... "
  count=0;

  if [ -f $JBOSS_PIDFILE ]; then
    read kpid < $JBOSS_PIDFILE
    let kwait=$SHUTDOWN_WAIT

    # Try issuing SIGTERM
    kill -15 $kpid
    until [ `ps --pid $kpid 2> /dev/null | grep -c $kpid 2> /dev/null` -eq '0' ] || [ $count -gt $kwait ]
    do
      sleep 1
      let count=$count+1;
    done

    if [ $count -gt $kwait ]; then
      echo "Matando o processo de numero $kpid"
      kill -9 $kpid
    fi
  fi
  rm -f $JBOSS_PIDFILE
  success
  echo "$SERVER_NAME parado com sucesso!"
  echo
}

status() {
  if [ -f $JBOSS_PIDFILE ]; then
    read ppid < $JBOSS_PIDFILE
    if [ `ps --pid $ppid 2> /dev/null | grep -c $ppid 2> /dev/null` -eq '1' ]; then
      echo "$SERVER_NAME está em execucao. (pid $ppid)"
      return 0
    else
      echo "$SERVER_NAME não está em execução, mas seu pidfile ainda existe"
      return 1
    fi
  fi
  echo "$SERVER_NAME está parado..."
  return 3
}

case "$1" in
  start)
      start
      ;;
  stop)
      stop
      ;;
  restart)
      $0 stop
      $0 start
      ;;
  log)
      readLog
      ;;
  status)
      status
      ;;
  *)
      ## If no parameters are given, print which are avaiable.
      echo "Usage: $0 {start|stop|status|restart|reload|log}"
      exit 1
      ;;
esac
